[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Numerics.BigInteger))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Numerics.Complex))]

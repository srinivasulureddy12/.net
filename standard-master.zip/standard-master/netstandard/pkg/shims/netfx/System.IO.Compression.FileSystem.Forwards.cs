[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.Compression.ZipFile))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.Compression.ZipFileExtensions))]

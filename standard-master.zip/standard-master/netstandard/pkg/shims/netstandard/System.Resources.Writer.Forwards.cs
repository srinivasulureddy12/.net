[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Resources.ResourceWriter))]

[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.Dns))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.IPHostEntry))]

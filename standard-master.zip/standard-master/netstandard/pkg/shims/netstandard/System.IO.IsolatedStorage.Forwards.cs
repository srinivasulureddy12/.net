[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.IsolatedStorage.IsolatedStorageException))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.IsolatedStorage.IsolatedStorageFile))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.IsolatedStorage.IsolatedStorageFileStream))]

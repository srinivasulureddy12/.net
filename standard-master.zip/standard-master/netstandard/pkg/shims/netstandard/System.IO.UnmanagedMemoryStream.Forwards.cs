[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.UnmanagedMemoryAccessor))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.UnmanagedMemoryStream))]

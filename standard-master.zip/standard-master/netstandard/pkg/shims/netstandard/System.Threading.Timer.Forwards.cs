[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.Timer))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.TimerCallback))]

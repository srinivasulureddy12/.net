[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.RegisteredWaitHandle))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.ThreadPool))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.WaitCallback))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.WaitOrTimerCallback))]

[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Xml.XPath.Extensions))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Xml.XPath.XDocumentExtensions))]

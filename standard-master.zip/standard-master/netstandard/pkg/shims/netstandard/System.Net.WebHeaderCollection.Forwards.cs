[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.HttpRequestHeader))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.HttpResponseHeader))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.WebHeaderCollection))]

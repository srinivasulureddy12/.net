[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.ComponentModel.Win32Exception))]

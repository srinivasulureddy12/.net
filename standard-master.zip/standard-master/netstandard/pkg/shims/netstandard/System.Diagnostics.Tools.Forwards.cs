[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.CodeDom.Compiler.GeneratedCodeAttribute))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.CodeAnalysis.SuppressMessageAttribute))]

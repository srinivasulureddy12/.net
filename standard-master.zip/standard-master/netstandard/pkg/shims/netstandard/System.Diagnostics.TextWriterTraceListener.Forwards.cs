[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.DelimitedListTraceListener))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.TextWriterTraceListener))]

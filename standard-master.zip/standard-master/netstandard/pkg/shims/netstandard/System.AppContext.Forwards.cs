[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.AppContext))]

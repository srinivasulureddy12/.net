[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.DriveInfo))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.DriveNotFoundException))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.DriveType))]

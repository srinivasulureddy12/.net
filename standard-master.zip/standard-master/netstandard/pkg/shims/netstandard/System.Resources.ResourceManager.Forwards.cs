[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Resources.MissingManifestResourceException))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Resources.NeutralResourcesLanguageAttribute))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Resources.ResourceManager))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Resources.SatelliteContractVersionAttribute))]

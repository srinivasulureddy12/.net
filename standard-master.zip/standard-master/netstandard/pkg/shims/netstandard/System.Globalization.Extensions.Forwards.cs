[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.StringNormalizationExtensions))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Globalization.GlobalizationExtensions))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Globalization.IdnMapping))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Text.NormalizationForm))]

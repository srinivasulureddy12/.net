[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.Tasks.Parallel))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.Tasks.ParallelLoopResult))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.Tasks.ParallelLoopState))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.Tasks.ParallelOptions))]

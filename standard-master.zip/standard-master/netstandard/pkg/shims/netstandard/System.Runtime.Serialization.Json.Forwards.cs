[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Runtime.Serialization.DateTimeFormat))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Runtime.Serialization.EmitTypeInformation))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Runtime.Serialization.Json.DataContractJsonSerializer))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Runtime.Serialization.Json.DataContractJsonSerializerSettings))]

[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.IOCompletionCallback))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.NativeOverlapped))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.PreAllocatedOverlapped))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Threading.ThreadPoolBoundHandle))]

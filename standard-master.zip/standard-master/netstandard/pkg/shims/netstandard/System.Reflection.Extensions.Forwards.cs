[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Reflection.CustomAttributeExtensions))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Reflection.InterfaceMapping))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Reflection.RuntimeReflectionExtensions))]

[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.FileVersionInfo))]

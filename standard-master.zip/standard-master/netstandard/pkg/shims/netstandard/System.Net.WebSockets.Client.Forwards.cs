[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.WebSockets.ClientWebSocket))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Net.WebSockets.ClientWebSocketOptions))]

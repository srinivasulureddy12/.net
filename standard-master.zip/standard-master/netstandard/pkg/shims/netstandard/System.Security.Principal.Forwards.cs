[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Security.Principal.IIdentity))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Security.Principal.IPrincipal))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Security.Principal.TokenImpersonationLevel))]

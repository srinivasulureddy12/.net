[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.StackFrame))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.StackFrameExtensions))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Diagnostics.StackTrace))]

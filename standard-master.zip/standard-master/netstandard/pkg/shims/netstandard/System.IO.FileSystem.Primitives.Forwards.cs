[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.FileAccess))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.FileAttributes))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.FileMode))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.IO.FileShare))]

[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Security.SecureString))]
[assembly:System.Runtime.CompilerServices.TypeForwardedTo(typeof(System.Security.SecureStringMarshal))]

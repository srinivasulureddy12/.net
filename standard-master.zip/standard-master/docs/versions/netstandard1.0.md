# .NET Standard 1.0

[Overview](../versions.md) | [Next](netstandard1.1.md)

* [APIs](netstandard1.0_ref.md)

## Platform Support

* .NET Core 1.0
* .NET Framework 4.5
* Mono
* Xamarin.iOS
* Xamarin.Android
* Universal Windows Platform 10
* Windows 8.0
* Windows Phone 8.1
* Windows Phone Silverlight 8.0

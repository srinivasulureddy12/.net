# Contributing

We'll add information that is more specific to .NET Standard in the future
here. For now, simply refer to the [contributing guide] in the CoreFX
repository.

[contributing guide]: https://github.com/dotnet/corefx/blob/master/Documentation/project-docs/contributing.md
